package com.example.gscct.triceratopstracker;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class viewlieu extends AppCompatActivity {
    DataBase myDB;
    DataBase2 myDB2;
    TextView title, date;
    LinearLayout ListePhotos;
    Button Supprimer;
    Button AjoutPhoto;
    int lieuId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewlieu);
        Intent myIntent = getIntent();
        myDB = new DataBase(this);
        myDB2 = new DataBase2(this);
        title = (TextView)findViewById(R.id.textView4);
        date = (TextView)findViewById(R.id.textView5);
        ListePhotos = (LinearLayout)findViewById(R.id.linearLayout);
        Supprimer = (Button)findViewById(R.id.button3);
        AjoutPhoto = (Button)findViewById(R.id.button11);
        lieuId = myIntent.getIntExtra("id",0);
        title.setText(myIntent.getStringExtra("title"));
        date.setText(myIntent.getStringExtra("date"));
        add_photo();
        delete_lieu();
    }

    public void add_photo(){
        final AppCompatActivity context = this;
        AjoutPhoto.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent startNewActivity = new Intent (context, TakePicture.class);
                        startActivity(startNewActivity);
                    }
                }
        );
    }

    public void delete_lieu(){
        Supprimer.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = myDB2.deleteLieu(lieuId);
                        if(deletedRows > 0) {
                            Toast.makeText(viewlieu.this, "Lieu supprimé", Toast.LENGTH_LONG).show();

                            finish();
                        }
                        else
                            Toast.makeText(viewlieu.this, "Lieu non supprimé", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }



    //PHOTO
    /*static final int REQUEST_IMAGE_CAPTURE = 1;

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }*/



}
